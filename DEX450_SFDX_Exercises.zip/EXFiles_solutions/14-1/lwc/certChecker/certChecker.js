import { LightningElement } from 'lwc';

export default class CertChecker extends LightningElement {
}