import { LightningElement } from 'lwc';

export default class CoursesAttended extends LightningElement { 
}