import { LightningElement } from 'lwc';

export default class CertAttempts extends LightningElement {  
}