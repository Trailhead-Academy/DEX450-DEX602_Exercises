import { LightningElement } from 'lwc';

export default class TechsCertsHeld extends LightningElement {  
}