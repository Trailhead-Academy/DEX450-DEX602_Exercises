import { LightningElement, api } from 'lwc';

export default class CertChecker extends LightningElement {
	@api recordId;
}